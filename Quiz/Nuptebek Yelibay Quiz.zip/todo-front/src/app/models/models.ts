export class Todo {
    id: number;
    name: string;
    phone: string;
    editing: boolean;
}

export class AuthResponse {
    token: string;
}
